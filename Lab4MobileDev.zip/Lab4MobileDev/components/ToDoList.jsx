import React from "react";
import { StyleSheet, Pressable, View, Text} from "react-native";

const ToDoList = ({tasks}) => {
  return tasks.map((task, index) => (
    <Pressable key={index}>
      <View style={[styles.task, styles.completed]}>
        <Text style={styles.taskText}>{task}</Text>
      </View>
    </Pressable>
  ));
};

export default ToDoList;

const styles = StyleSheet.create({
  task: {
    padding: 10,
    borderBottomWidth: 2,
    borderColor: "#fff",
  },
  completed: {
    backgroundColor: "lightblue",
  },
  taskText: {
    fontSize: 20,
    color: "red"
  },
});
