/**
 * My To Do List App
 *
 * @format
 */

import React, { useState } from "react";
import { SafeAreaView, ScrollView } from "react-native";
import ToDoForm from "../../components/ToDoForm";
import ToDoList from "../../components/ToDoList";

function App() {
  const [tasks, setTasks] = useState(["Go to school", "take out the trash", "pick up sister"]);

  const addTask = (taskText: string) => {
    if (taskText === "") {
      alert("Input can't be empty")
      return;
    }
    if (tasks.includes(taskText)) {
      alert(`${taskText} is already in list`);
    } else {
      setTasks([...tasks, taskText]);
    }
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <ToDoList tasks={tasks}></ToDoList>
      </ScrollView>

      <ToDoForm addTask={addTask}></ToDoForm>
    </SafeAreaView>
  );
}

export default App;
